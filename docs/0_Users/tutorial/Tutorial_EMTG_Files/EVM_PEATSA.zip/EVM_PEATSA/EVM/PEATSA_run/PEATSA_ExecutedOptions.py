# PEATSA options script
# written by PEATSA menu class


# -------------------------------------------- Path Options --------------------------------------------

# Where should PEATSA work? Enter a string.
run_name = 'PEATSA_run'

# Where should PEATSA work? Enter a string.
working_directory = '/home/ts34254/EMTG/missions/EVM/PEATSA_run/'

# What machine(s) will run the emtg cases? 
        # This is a list of tuples. Each tuple is: 
        # (an IP address string or 'local' for the current machine, number of cores available on that host)
        # NOTE! DO NOT USE ANYTHING BUT LOCAL UNLESS ALL MACHINES HAVE SHARED MEMORY AND
        # working_directory is pointing to a shared folder on all machines
nCores = [
          ('local', 4)
         ]

# Where is EMTG located? The emtgv9 executable should be in this directory and 
        # the PyEMTG files should be located in: emtg_root_directory + '/PyEMTG'.
        # Enter a string.
emtg_root_directory = '/home/ts34254/repo/emtg'

# What is the name of the executable? Enter as a string. Typically emtg or EMTGv9
executable_name = 'EMTGv9'

# Where would you like to log the results? Enter a string.
logfile = '/home/ts34254/EMTG/missions/EVM/peatsa.log'

# Would you like PEATSA to run in a slimmer memory mode? It will use less memory but will require more time between iterations.
thin_crust = False


# ------------------------------------------- Start Options --------------------------------------------

#Choose which execution method is used.
                        # 0: Traditional PEATSA
                        # 1: Noble's new version
                        # 2: Noble's new verion with pebble
execution_type = 0

# What is the maximum number of iterations PEATSA is allowed to run before exiting? (Integer >= 0)
max_iterations = 2

# Would you like PEATSA to keep only two Cases and Results subdirectories? (IterationPrevious and IterationCurrent).
             # If true, you will use less disk space but lose the exhaustive history of PEATSA iterations.
             # Currently can only be used with a Fresh start.
keep_only_current_and_previous = False

# How should PEATSA start?
        # start_type = 'Fresh', New PEATSA cases will be created
        # start_type = 'Warm', PEATSA will start by running cases in an existing folder
        # start_type = 'Hot', PEATSA will start by parsing a set of cases, re-seeding them
        #                       and then running those new cases
start_type = 'Fresh'

# What type of PEATSA run is this? 
        # PEATSA_type = 0, custom 
        # PEATSA_type = 1, missed thrust
        # PEATSA_type = 2, trade study
        # PEATSA_type = 3, missed thrust trade study
        # PEATSA_type = 4, batch run a single case
        # PEATSA_type = 5, maneuver execution error monte carlo
PEATSA_type = 2

# Should cases be run or not? Should the PEATSA oven be called? Enter a 1 or 0.
if_run_cases = 1

# If start_type == 'Warm', what iteration to start from? Enter an integer.
iteration = 0

# If start_type == 'Hot' or 'Warm', where are the results to start from? Enter a list of tuples:
        # ('path to results','parse_type'
        # parse_type = 'Full' : PEATSA will load every emtg and emtgopt in every subdirectory pointed to by the path/to/results
        #                       It is assumed that the folder structure is: /path/to/results/Iteration#/EMTGandEMTGOPTfiles
        # parse_type = 'Best' : PEATSA will only load the emtg and emtgopt files specified in the latest iteration csv in each /path/to/results/docs
        #                       It is assumed that the path/to/results is actually a path to a peatsa root folder
        # parse_type = 'Warm' : PEATSA will not load any results, it will just run the cases in /path/to/results/cases/
restart_run_root_directory = [
                              ('/Users/jknittel/scratch/PEATSA/PEATSA_run', 'Full')
                             ]

# If start_type == 'Hot', do you want to copy the results from previous peatsa runs
        # into the current run's iteration0 results folder? This will take a long time, but
        # will save time in future hot starts. Enter a 1 or 0.
copy_previous_results = 0


# ----------------------------------- Initial Case Creation Options ------------------------------------

# If PEATSA_type == 0, enter the path to a python script which will generate
        # the cases as part of the PEATSA run. This is meant to be used if the default
        # PEATSA file generators for trade studies and missed thrust studies aren't
        # sufficient for any reason. Enter a path as a string. The file must:
        #      1)  Be valid python code, ending with .py
        #      2)  Define a method called 'CustomPEATSAchef'
        #      3)  CustomPEATSAchef must take a PEATSAmenu object as it's only input
        #      4)  Write the mission objects into PEATSAorder.cases_directory
        #      5)  Return a list of PEATSAbox objects with nothing but the PEATSAdough path set
custom_PEATSA_chef_path = ''

# How many samples would you like to run in the monte carlo?
nSamples = 100

# What are the standard deviations of thrusting error? Enter a list:
        # [% Magnitude error,Body Fixed Angle 1 [deg], Body Fixed Angle 2 [deg]]
thrusting_standard_deviations = [
                                 0.0,
                                 0.0,
                                 0.0
                                ]

# What is the range of epochs over which you want to monte carlo the maneuvers? Enter a list:
        # [Earliest Julian Date, Latest Julian Date]
epoch_range = [
               0,
               10000000000.0
              ]

# When optimizing monte carlo 'missions to go', do you want to optimize through the full reference mission,
        # or stop after a specified journey? Enter the last journey you want in the 'mission to go' optimizations.
        # Note: python negative indexing is fine
stop_after_journey = -1

# Where are the reference files? Enter a path as a string.
reference_files_location = ''

# What is the name of the reference options file? Enter a string.
reference_options_file_name = ''

# What is the name of the reference mission file? Enter a string.
reference_mission_file_name = ''

# Provide a path to the manuever_spec file for the reference mission
maneuver_file = '/home/ts34254/EMTG/missions/EVM/results/EVM_PEATSA_Init/EVM.mission_maneuver_spec'

# If running a missed thrust case, what is the path to the spk input data file
        # that contains ephemeris for the reference trajectory. Enter a path as a string.
        # PEATSA expects a .ephemeris file with a mass column.
reference_spk_data_file = ''

# If performing a trade study, where are the options being traded stored?
        # Enter a list of tuples. Each tuple should have the format:
        # (string of path to csv file,options file type)
        # The path to the file should be full, not relative from anywhere.
        # There are three formats that the file can be created. All three formats
        # should be csv files though (It is assumed you will use excel to create the file
        # and then save it as a csv). The three formats are:
        # options file type = 0: Trade all values for a given variable individually against the default values of all other variables.
        #                        First two rows specify the reference files location and emtgopt filename respectively
        #                        Third row specifies the PyEMTG MissionOptions variables being traded. Use 'MO.' to access mission option data,
        #                                                                                              Use 'SO.' to access spacecraft option data
        #                                                                                              Use 'StgO[n].' to access stage n option data
        #                        Fourth row lists the default value for the column it resides.
        #                        Subsequent rows, as many as desired, indicate all other options for that variable.
        #                        An example version of this file is in the PEATSA folder named 'opt_file_type_one.csv'
        #                        The total number of cases generated will be equal to the sum of the number of all entries in the third row and below
        # options file type = 1: Trade all values of each variable against all values of all other variables.
        #                        First two rows specify the reference files location and emtgopt filename respectively
        #                        Third row specifies the PyEMTG MissionOptions variables being traded. Use 'MO.' to access mission option data.
        #                                                                                              Use 'SO.' to access spacecraft option data
        #                                                                                              Use 'StgO[n].' to access stage n option data
        #                        Subsequent rows, as many as desired, indicate all other options for that variable.
        #                        An example version of this file is in the PEATSA folder named 'opt_file_type_two.csv'
        #                        The total number of cases generated will be equal to the multiplicative of the number of entries in each column (not counting the top row)
        # options file type = 2: List out the exact combinations of each variable.
        #                        First two rows specify the reference files location and emtgopt filename respectively
        #                        Third row specifies the PyEMTG MissionOptions variables being traded. Use 'MO.' to access mission option data.
        #                                                                                              Use 'SO.' to access spacecraft option data
        #                                                                                              Use 'StgO[n].' to access stage n option data
        #                        Subsequent rows, as many as desired indicate the combinations of those variables to be considered.
        #                        An example version of this file is in the PEATSA folder named 'opt_file_type_three.csv'
        #                        The total number of cases generated will be equal to the number of rows (not counting the top row)
trade_study_options_files = [
                             ('/home/ts34254/EMTG/missions/EVM/peatsa_options.csv', 1)
                            ]

# If you are just using this code to create new cases that will be added into another 
        # PEATSA run, then you can start the filename's X in 'TradeStudy_CaseX' at a nonzero value.
        # What index should new cases start at?
starting_case_index = 0

# If running a missed thrust case, how frequently, should cases be created?
        # If missed_thrust_timestep <= 1 : PEATSA will create a timestep that is that percentage of the given phase's timestep
        # If missed_thrust_timestep > 1 : PEATSA will use the timestep directly as number of days
missed_thrust_timestep = 7

# Should missed thrust recovery cases be started during forced coasting periods? Enter a 1 or 0.
skip_forced_coast_periods = 1

# If the mission has coast phases, would you like to remove these from the missed thrust recovery cases?
convert_3d_to_patched_conic = 0

# If running a missed thrust case, what propellant margin should the mission maintain?
        # for the propellant remaining when the missed thrust event is over? Because Bruno Sarli
        # is bad at math, you can specify units using either 'pct' or 'kg'. The whole thing
        # must be a string. For example, '10 pct' or '100 kg'.
        # If no units are specified, it will be assumed that the value is a percentage as a number from 0 to 1.
post_missed_thrust_electric_propellant_margin = 0.0

# If running a missed thrust case, what propellant margin should the mission consider
        # itself to have used before the missed thrust event?
        # For example, if the mission used 200 kg of propellant before the missed thrust
        # event, and there are 100 kg of propellant remaining 'in the tank', we need to
        # determine how much of the remaining 100 kg are actually usable. If the mission
        # is to maintain a 10%% propellant margin over the entire mission, then only 80 kg
        # of the remaning propellant are usable, because the margin on the 200 kg used
        # so far is 20 kg.  
        # pre_missed_thrust_electric_propellant_margin < 0, use the value from the reference mission
        # pre_missed_thrust_electric_propellant_margin > 0 use the percentage specified (enter a number 0 to 1)
pre_missed_thrust_electric_propellant_margin = -1.0

# If running a missed thrust case, should the pre-missed thrust event propellant
        # be vented? Once the missed thrust event is over, the propellant that was book-kept
        # as margin for the propellant used up until the event, is nominally converted to
        # 'dry mass' in EMTG. However, this mass could be vented instead, which would reduce
        # the mass on-board for missed thrust recovery
        # Enter 1 or 0.
vent_pre_missed_thrust_electric_propellant_margin = 0

# How many days should be removed from any terminal forced coasts for missed thrust recovery cases?
        # If missed_thrust_recovery_forced_terminal_coast_reduction > 0 : PEATSA will reduce the coast by an amount that is that percentage of the given phase's timestep. Enter a float, but integers are probably smarter.
        # If missed_thrust_recovery_forced_terminal_coast_reduction < 0 : PEATSA will use the reduction directly directly as a number of days.
missed_thrust_recovery_forced_terminal_coast_reduction = 0.0

# Would you like to use the default duty cycle to propulate or a different value? If a different
        # value, then enter the duty cycle (i.e. .95). Otherwise enter zero.
override_propulated_duty_cycle = 0.0


# ---------------------------------------- EMTG Control Options ----------------------------------------

# How long (in seconds) before a case needs to be killed?
       # Make this value at least the MBH max run time + the NLP max run time + some buffer time
       # for writing to file. Buffer time depends on the complexity of the case, whether
       # or not you are generating ephemeris files, etc. Recommend at least 30 seconds.
killtime = 100

# How long (in seconds) should cases be run in EMTG?
MBH_max_run_time = 60


# ---------------------------------------- Optimization Options ----------------------------------------

# What is the objective type?
        # objective_type == 0, objective_function better than peatsa_objective
        # objective_type == 1, objective_function better than polyfit = objective_fun(seed_value)
objective_type = 0

# How can PEATSA evaluate the objective value?
        # Input a string that can be evaluated. EMTG Mission data can be gathered using 'M.' and 
        # Mission option data is available using 'MO.'
objective_formula = 'M.total_deterministic_deltav'

# Is this a maximization or minimization problem? Enter 'max' or 'min'.
max_or_min = 'min'

# If PEATSA's objective_type == 0, what is the target objective value? I.E. for missed thrust, the 
        # target could be 60 days. Or for maximum mass, the target could be 100 
        # kg. In some cases the goal objective will be the same as the EMTG
        # objective_type, but it doesnt have to be. If a good target is not
        # known, then simply set it to something impossible to reach. I.e. for 
        # missed thrust, 1e100, or for minumum time, -1 days. The value here should 
        # have the same units as whatever the 'objective_formula' will evaluate to.
peatsa_goal_objective = 0.0

# If PEATSA's objective_type == 1, then an order for the polynomial fit is needed. Enter an integer.
polyfit_order = 1

# If PEATSA's objective_type == 1, then a margin is used so that the case value does not
        # need to exceed the EXACT expected value from the polynomial fit. For example, if the polyfit
        # predicts a value of 100, and the result for this case is 99, then we would need a margin of .01 
        # or 1% to prevent the case from being re-run. If the result for the case is 95, then it still is likely 
        # 'good enough', and doesnt need to be re-run, so a margin of 5 to 10% is typically appropriate. Enter a float 0 to 1.
polyfit_margin = 0.1

# Would you like to release constraints if PEATSA stalls? Enter a list of tuples. Each tuple has the form:
        # (string of constraint as a PyEMTG MissionOption,how many failed iterations to wait before loosening constraint, increment)
        # The first entry should be a variable in the PyEMTG MissionOption class, such as: 'MO.Journeys[-1].arrival_date_bounds[1]'
        # The second entry is how many times no PEATSA cases found improvement before the constraint will be loosened.
        # Finally enter the increment to change the constraint each time this event is triggered.
constraint_walking = [
                     ]


# ------------------------------------------ Sorting Options -------------------------------------------

# What makes each case in this PEATSA run unique? Write a list of strings
        # that will be evaluated for each case to give it a unique fingerprint. 
        # For data from an EMTG mission option, use 'MO.'. Do not use data
        # from an EMTG mission. Cases need fingerprints even if they dont converge.
        # Do not put any formulas that are already in the seed_criteria list.
fingerprint = [
               "MO.launch_window_open_date",
               "MO.Journeys[0].initial_impulse_bounds[1]"
              ]


# -------------------------------------- Case Re-creation Options --------------------------------------

# CURRENTLY BUGGY, DO NOT USE.
            # Do you want to find seeds in parallel? (0 or 1).
            # Uses find_seeds_in_parallel_nCores number of cores.
find_seeds_in_parallel = 0

# If find_seeds_in_parallel == 1, this is how many parallel processes are used to find seeds. Integer >= 1.
find_seeds_in_parallel_nCores = 1

# CURRENTLY BUGGY, DO NOT USE.
            # Do you want to write seeds in parallel? (0 or 1).
write_seeds_in_parallel = 0

# If write_seeds_in_parallel == 1, this is how many parallel processes are used to write seeds. Integer >= 1.
write_seeds_in_parallel_nCores = 1

# Are there additional folders that contain emtg cases that can be used as seeds
        # for the current PEATSA run, but are not valid cases. For example, a group of results
        # that seem feasible to PEATSA, but the EMTG feasibility criteria changed internally to
        # EMTG, so all the old cases need to be tossed, but the initial guesses are still useful.
        # Enter a list of tuples:
        # (folder_type,full_folder_path)
        # if folder_type == 0, then the folder is a peatsa results folder with many iteration
        #                      subdirectories, all of which will be included
        # if folder_type == 1, then the folder is an individual results folder and only its contents
        #                      will be parsed, with all subdirectories ignored.
seed_folders = [
               ]

# When fresh starting, if you have an external seed folder, would you like to use it before the first iteration runs?
seed_from_seed_folders_on_fresh_start = False

# Should cases be allowed to seed themselves? Or only their neighbors? Enter 1 or 0
allow_cases_to_seed_themselves = 1

# How do you want to generate initial guesses?
        # if initial_guess_type == 'x_days', then the number of timesteps in the mission itself
        #                                    will be modified such that each timestep is ~ x days
        #                                    (use new_timestep to define x)
        # if initial_guess_type == 'n_steps', then the number of timesteps in the mission will
        #                                     be kept the same or modified to be n steps
        #                                     (use new_timestep to define x)
        # if initial_guess_type == 'copy', then PEATSA will just copy the initial guess over without
        #                                  attempting to interpolate
initial_guess_type = 'copy'

# What do you want the new timestep to be?
        # if initial_guess_type == 'x_days',
        #          if new_timestep == -2, then the number of days in each journey control step will be copied from the seed mission
        #          if new_timetsep > 0, then all journeys will be given this timestep in days
        #          if new_timestep = [x,y,z], then the final 3 journeys will be given x,y,z days
        #                                     timesteps respectively. if len(new_timestep) > len(new_timestep),
        #                                     entries from new_timestep will be matched backwards. I.E:
        #                                     MO.Journeys[-1].journey_number_of_timesteps = new_timestep[-1]
        #                                     MO.Journeys[-2].journey_number_of_timesteps = new_timestep[-2], etc.
        #                                     Note: len(new_timestep)  < len(Journeys) will throw an error
        # if initial_guess_type == 'n_steps,
        #          if new_timestep == -2, then the number of timesteps will be copied from seed mission
        #          if new_timestep == -1, then the number of timesteps will not be modified from mission options
        #          if new_timestep > 0, then all journeys will be given this number of timesteps
        #          if new_timestep = [x,y,z], then the final 3 journeys will be given x,y,z
        #                                     timesteps respectively. if len(new_timestep) > len(new_timestep),
        #                                     entries from new_timestep will be matched backwards. I.E:
        #                                     MO.Journeys[-1].number_of_timesteps = new_timestep[-1]
        #                                     MO.Journeys[-2].number_of_timesteps = new_timestep[-2], etc.
        #                                     Note: len(new_timestep)  < len(Journeys) will throw an error
new_timestep = -1

# If a case doesnt have a seed, rather than running unseeded, should it keep using whatever is in its trialX,
        # presumably the seed from reference mission. Or do you want to turn off seed_MBH and actually start without an initial guess?
turn_off_seed_MBH_when_unseeded = 0

# If a case doesnt have a seed, rather than running unseeded, should it seed from the end of its last run,
        # even though it didnt find something feasible at the end of the last run?
seed_from_infeasible_self_when_unseeded = 0

# Would you like cases to be able to be seeded from infeasible seeds if no feasible seeds were found?
seed_from_infeasible_cases_if_no_feasible_seeds_found = False

# Should cases that don't meet the goal criteria be considered as potential seeds?
        # WARNING: potential seed cases will be evaluated against peatsa_goal_objective
        # even if PEATSA_objective_type == 1. 
        # Enter a 1 or 0.
seed_from_cases_that_havent_met_target = 1

# Flag to override the individual seed selection criterias specified in 'seed_criteria'.
        # Instead, only one total seed will be selected regardless of which seed criteria was used. 
        # Note: This variable is a replacement for the old only_seed_from_best_in_all_seed_directions variable 
        # Valid choices: 
        # 0: Do not use 
        # 1: Only the best seed from all directions will be used (i.e., the old only_seed_from_best_in_all_seed_directions) 
        # 2: One randomly selected seed from amongst all seed directions that produced a valid seed will be used.
only_one_seed_in_all_seed_directions = 1

# How can PEATSA evaluate the seed criteria?
        # Input a list of tuples. Each tuple is: 
        # (a string that can be evaluated, max negative seed range, max positive seed range, seed selection criteria)
        # For the evaluation string, EMTG Mission data can be gathered using
        # 'MO.'. Don't use mission data, because even failed cases need to know how to
        # pick a seed.
        # For the max seed range, answer if there should be a maximum range for seeding, and if so, how long?
        # max_negative_seed_range > 0, there is no maximum range in the negative direction
        # max_negative_seed_range <= 0, this is the maximum range, in the units of whatever
        #       seed_criteria evaluates in 
        # max_positive_seed_range < 0, there is no maximum range in the negative direction
        # max_positive_seed_range >= 0, this is the maximum range, in the units of whatever
        #       seed_criteria evaluates in 
        # For the seed selection criteria, specify how PEATSA should select new seeds?
        # seed_selection_criteria == 0, seed from the closest potential seed
        # seed_selection_criteria == 1, seed from all potential seeds
        # seed_selection_criteria == 2, seed from only the best potential seed
        # seed_selection_criteria == 3, seed from random potential seed
        # seed_selection_criteria == 4, seed from a curve fit of all potential seeds.
        #                               Each decision vector variable is a curve fit
        #                               of a curve fit of the corresponding decision vector values
        #                               from all of the seeds. Uses polyfit_order for the curve fit order.
seed_criteria = [
                 ('MO.launch_window_open_date', -30.1, 30.1, 2),
                 ('MO.Journeys[0].initial_impulse_bounds[1]', -1.1, 1.1, 2)
                ]

# NOTE: We are currently not sure whether or not this actually works.
       # Should cases not be run until a seed can be found for them?
        # Note: they will be run for the 0th iteration. But in the reseeding process,
        # If a seed cant be found for it, then it will not be put back on the queue
        # Enter 1 or 0
wait_until_seeded = 0

# Enter a list of strings that will can be evaluated as a conditional statement. Each condition will filter out cases that should be ignored. These conditions
        # are applied using 'or' logic, assuming that no cases will be re-run unless these conditions are met.
        # If left empty, the normal conditions apply. If applied, the cases will still be compared to the PEATSA objective, so
        # cases that meet the 'only_rerun_if', still might not be re-run if they also meet the stopping criteria.
        # Note: this does not remove cases from the PEATSA run entirely. It only adds
        # a condition, which if not met, will prevent cases from being re-run. But
        # thoses filtered cases will still appear in csv summary files.
        # Use 'M.' to access EMTG mission object data and 'MO.' to access EMTG mission options data.
        # Example only_rerun_if = ['MO.launch_window_open_date > 64000','M.spacecraft_dry_mass < 100 and M.total_flight_time_years > 30']
only_rerun_if = [
                ]

# Are there any options that you want to override from the default options?
        # Enter a tuple of: 
        # (string of condition of when to use the option, string of formula for option)
        # Use MO for the mission options object.
        # It is very likely that you want to at least override the directory paths for
        # HardwareModels and Universe.
        # Example: override_options = [('1','MO.launch_window_open_date = 23432'),('len(MO.Journeys) > 3','MO.Journeys[3].destination_list[1] = 2')]
override_options = [
                    ('1', 'MO.MBH_max_run_time = 90')
                   ]


# -------------------------------------- Post-processing Options ---------------------------------------

# Should peatsa parse using multiple local cores? Enter a 1 or 0.
        # A 1 means that peatsa will parse results in parallel using parse_in_parallel_nCores.
        # Note that starting up parallelization is not free, which means that parallelizing will actually
        # be SLOWER if the number of cases is not much greater than the number of cores being used.
        # However, if you have thousands or tens of thousands of cases, you can definitely save time by parallelizing.
parse_in_parallel = 0

# If parse_in_parallel == 1, how many cores should PEATSA use to parse in parallel?
        # Enter an integer >= 1 and <= the number of available cores.
parse_in_parallel_nCores = 1

# Do you want any extra data printed to each iteration's csv summary?
        # If not, leave this as an empty list
        # If so, add tuples of:
        # ('column header','string of formula to be evaluated')
        # For data from an EMTG mission, use 'M.', and for an EMTG mission option, use 'MO.'
extra_csv_column_definitions = [
                                ('C3 (km^2/s^2)', 'M.Journeys[0].missionevents[0].C3'),
                                ('Launch Date', 'M.Journeys[0].missionevents[0].GregorianDate'),
                                ('Launch Date (JD)', 'M.Journeys[0].missionevents[0].JulianDate')
                               ]

# NOTE: These plots are not necessarily all that useful, but see for yourself.
       # Should the default plots be generated?
        # For trade studies, each option being traded will be plotted 
        # on the x axis vs. the 'objective_value' on the y-axis. Note: this 
        # currently only works for trade study type 0 files.
        # For missed thrust, missed thrust event date will be plotted on the x axis vs departure coast possible on the y-axis.
generate_default_plots = 0

# Would you like to generate custom plots using the built-in plotter? If so, enter a list of paths as strings to csv files which
        # contain options for a plot
built_in_plotter_files = [
                         ]

# Would you like to call a custom post processing script? Enter a path as a string.
        # This script will be called after each iteration. It can generate extra summary files, in addition to
        # the .csv file generated already, or extra plots, in addition to the defaults or any made with the built-in plotting routine.
        # Enter the path of a python module. The file must:
        #      1)  Be valid python code, ending with .py
        #      2)  Define a method called 'PEATSAPostProcess'
        #      3)  PEATSAPostProcess must take a PEATSAmenu object as its first input
        #      4)  PEATSAPostProcess must take a python list of PEATSAbox objects as its second input
        # It is not necessary, but data files can be saved to 'PEATSAorder.docs_dir' and plots can be saved to 'PEATSAorder.images_dir'
custom_post_processing_script = ''

# Would you like peatsa to move the latest results to another folder for easier ftp'ing?
        # If so, provide a full path to the desired destination. If not, leave an empty string.
move_results = ''


